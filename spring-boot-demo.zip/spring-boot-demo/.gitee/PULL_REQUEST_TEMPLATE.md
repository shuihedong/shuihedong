* PR 修复缺陷请先开 `issue` **[报告缺陷](https://github.com/xkcoding/spring-boot-demo/issues/new?template=bug_report.md)**
* PR 提交新特性请先开 `issue` **[报告新特性](https://github.com/xkcoding/spring-boot-demo/issues/new?template=feature_request.md)**
* PR 请提交到 `dev` 开发分支上
* 我们对编码风格有着较为严格的要求，请在阅读代码后模仿类似风格提交
* 欢迎通过 PR 给我们补充案例
