/**
 * service 层，继承并实现 spring 接口.
 *
 * @author <a href="https://echocow.cn">EchoCow</a>
 * @date 2020/1/7 上午9:16
 */
package com.xkcoding.oauth.service;
